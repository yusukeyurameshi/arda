set lines 400
set pages 50000

spool DB_STATS.txt

select a.*
  from V$RMAN_STATUS a
 where trunc(start_time) > trunc(sysdate - 10)
 order by START_TIME;

SELECT d.tablespace_name
	,d.status
	,d.contents PTYPE
	,d.extent_management EXTENT_MGMT
	,round(NVL(sum(df.bytes) / 1024 / 1024, 0),2) SIZE_MB
	,round(NVL(sum(df.bytes) - NVL(sum(f.bytes), 0), 0)/1024/1024,0) USED_MB
	,round(NVL((sum(df.bytes) - NVL(sum(f.bytes), 0)) / sum(df.bytes) * 100, 0),0) USED_PERCENT
	,d.initial_extent
	,NVL(d.next_extent, 0) NEXT_EXTENT
	,round(NVL(max(f.bytes) / 1024 / 1024, 0),0) LARGEST_FREE
  FROM dba_tablespaces d
	,dba_data_files df
	,dba_free_space f
 WHERE d.tablespace_name = df.tablespace_name
   AND df.tablespace_name = f.tablespace_name  (+)
   AND df.file_id  = f.file_id  (+)
 GROUP BY d.tablespace_name, d.status, d.contents, d.extent_management
	  ,d.initial_extent, d.next_extent
 ORDER BY 1,2,3;

SELECT round(sum(value)/1024/1024,1) SGA_MB
  FROM gv$sga a;

SELECT substr(name,0,512) name
	,NVL(SUBSTR(value,0,512) , 'null value') value
  FROM  v$parameter;

SELECT a.*
  FROM NLS_DATABASE_PARAMETERS a;

SELECT A.*
  FROM v$version A;

select *
  from (select min(to_char(b.begin_interval_time, 'dd-mm-yy hh24:mi')) inicio,
               max(to_char(b.end_interval_time, 'dd-mm-yy hh24:mi')) fim,
               round(max(case
                           when a.stat_name = 'PHYSICAL_MEMORY_BYTES' then
                            a.value
                           else
                            null
                         end) / 1024 / 1024,
                     0) - round(max(case
                                      when a.stat_name = 'FREE_MEMORY_BYTES' then
                                       a.value
                                      else
                                       null
                                    end) / 1024 / 1024,
                                0) PHYSICAL_USED_MEM,
               round(max(case
                           when a.stat_name = 'PHYSICAL_MEMORY_BYTES' then
                            a.value
                           else
                            null
                         end) / 1024 / 1024,
                     0) PHYSICAL_TOTAL_MEM,
               a.snap_id
          from dba_hist_osstat a, dba_hist_snapshot b, dba_hist_osstat c
         where a.dbid = b.dbid
           and a.snap_id = b.snap_id
           and a.snap_id - 1 = c.snap_id
           and b.end_interval_time > sysdate - 10
         group by a.snap_id
         order by 1) b;

select to_char(first_time,'YYYY.MM.DD') day,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'00',1,0)),'99') hour_00,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'01',1,0)),'99') hour_01,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'02',1,0)),'99') hour_02,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'03',1,0)),'99') hour_03,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'04',1,0)),'99') hour_04,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'05',1,0)),'99') hour_05,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'06',1,0)),'99') hour_06,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'07',1,0)),'99') hour_07,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'08',1,0)),'99') hour_08,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'09',1,0)),'99') hour_09,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'10',1,0)),'99') hour_10,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'11',1,0)),'99') hour_11,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'12',1,0)),'99') hour_12,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'13',1,0)),'99') hour_13,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'14',1,0)),'99') hour_14,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'15',1,0)),'99') hour_15,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'16',1,0)),'99') hour_16,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'17',1,0)),'99') hour_17,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'18',1,0)),'99') hour_18,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'19',1,0)),'99') hour_19,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'20',1,0)),'99') hour_20,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'21',1,0)),'99') hour_21,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'22',1,0)),'99') hour_22,
        to_char(sum(decode(substr(to_char(first_time,'DDMMYYYY:HH24:MI'),10,2),'23',1,0)),'99') hour_23
   from v$log_history
   group by to_char(first_time,'YYYY.MM.DD')
   order by 1;

SELECT a.*
  FROM v$license a;

SELECT min(to_char(begin_time,'dd-mm-yy hh24:mi')) inicio,
       max(to_char(end_time,'dd-mm-yy hh24:mi')) fim,
       round(sum(case metric_name when 'Host CPU Utilization (%)' then average end),1) Host_CPU_util,
       round(sum(case metric_name when 'Physical Read Total Bytes Per Sec' then average end)/1024/1024,1) Physical_Read_MBps,
       round(sum(case metric_name when 'Physical Write Total Bytes Per Sec' then average end)/1024/1024,1) Physical_Write_MBps,
       round(sum(case metric_name when 'Physical Read Total IO Requests Per Sec' then average end),1) Physical_Read_IOPS,
       round(sum(case metric_name when 'Physical Write Total IO Requests Per Sec' then average end),1) Physical_write_IOPS,
       round(sum(case metric_name when 'Redo Writes Per Sec' then average end),1) Physical_redo_IOPS,
       round(sum(case metric_name when 'Network Traffic Volume Per Sec' then average end)/1024/1024,1) Network_Mb_per_sec,
       snap_id
  from dba_hist_sysmetric_summary
  where trunc(begin_time) > trunc(sysdate-10)
  group by snap_id
  order by snap_id;

SELECT version,
       name,
       detected_usages,
       currently_used,
       first_usage_date,
       last_usage_date
  from DBA_FEATURE_USAGE_STATISTICS
 where detected_usages > 0
 order by name;

col FILENAME format a180

SELECT df.tablespace_name
	,df.file_name FILENAME
	,df.file_id
	,df.status
	,round(NVL(df.bytes / 1024 / 1024, 0),0) SIZE_MB
	,round(NVL(df.bytes - NVL(sum(f.bytes), 0), 0)/1024/1024,0) USED_MB
	,round(NVL((df.bytes - sum(nvl(f.bytes,0))) / df.bytes * 100, 0),0) USED_PERCENT
  FROM dba_data_files df
       ,dba_free_space f
 WHERE df.tablespace_name = f.tablespace_name  (+)
   AND df.file_id   = f.file_id  (+)
 group by df.tablespace_name, df.file_name, df.file_id, df.status, df.bytes
 order by 1,2,3;


spool off
exit